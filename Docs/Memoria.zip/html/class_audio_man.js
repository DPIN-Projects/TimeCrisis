var class_audio_man =
[
    [ "bckgrnd_music_volume", "class_audio_man.html#af481db7094c89f630a6bf97390fed07c", null ],
    [ "sfx_volume", "class_audio_man.html#a82d7cca4df83ded9dcc9d661e1f4bae4", null ],
    [ "Instance", "class_audio_man.html#a5a8b52b52533bb05c77437cf9dcdec0f", null ]
];