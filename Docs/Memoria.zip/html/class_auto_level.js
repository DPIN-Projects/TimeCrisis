var class_auto_level =
[
    [ "to_level", "class_auto_level.html#aa4b78d86eb7b6de6f6d5d8431eb811d0", null ]
];