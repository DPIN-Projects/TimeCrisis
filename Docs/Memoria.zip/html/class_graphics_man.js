var class_graphics_man =
[
    [ "ChangeRes", "class_graphics_man.html#a5b0e7ab49115dcfdd38f0665079b7680", null ],
    [ "FullScreen", "class_graphics_man.html#a7c1bffa631e4be0a1f9f949af4a996c3", null ],
    [ "fullscreen", "class_graphics_man.html#a30c79e30dcb18258d022419cf6a4c8d6", null ],
    [ "width", "class_graphics_man.html#a6d036e29ff4ff57f9856dd1df39a7013", null ],
    [ "Instance", "class_graphics_man.html#a004fcc351881be67f3553244881bb5dd", null ]
];