var class_gun_data =
[
    [ "max_bullets", "class_gun_data.html#ac8fdd120e482365f3c2a2775b520d8ec", null ],
    [ "sfx_shot", "class_gun_data.html#a4065a3c88840c9f4de969de8575ec59f", null ]
];