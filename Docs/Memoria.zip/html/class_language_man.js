var class_language_man =
[
    [ "LanguageType", "class_language_man.html#a17847f05d76a6c54d90b32629d4d91d3", [
      [ "English", "class_language_man.html#a17847f05d76a6c54d90b32629d4d91d3a78463a384a5aa4fad5fa73e2f506ecfc", null ],
      [ "Spanish", "class_language_man.html#a17847f05d76a6c54d90b32629d4d91d3acb5480c32e71778852b08ae1e8712775", null ],
      [ "NumberOfTypes", "class_language_man.html#a17847f05d76a6c54d90b32629d4d91d3ac547342537ca85aeb8be82a349cbb6a2", null ]
    ] ],
    [ "LoadLanguage", "class_language_man.html#ad41cc80345932cb1a30f31769b4a8f2e", null ],
    [ "lan_type", "class_language_man.html#a76a925e866a0c7db4b71d7b1e818fa1c", null ],
    [ "Instance", "class_language_man.html#af7de0ce7ef6cdc6056a801f3be44ee04", null ]
];