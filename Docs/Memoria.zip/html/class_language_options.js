var class_language_options =
[
    [ "NextLanguage", "class_language_options.html#a0b9b2fa39befb1df062361cac0859f66", null ],
    [ "PrevLanguage", "class_language_options.html#a12c9dcccd3d63622ac3674e5f4828592", null ]
];