var class_main_menu_controller =
[
    [ "ExitGame", "class_main_menu_controller.html#ac932610988eda8e09c4f8051bc27dad8", null ],
    [ "LoadMain", "class_main_menu_controller.html#a50a7a4096d69462d51db2a068688f1a8", null ],
    [ "LoadOptions", "class_main_menu_controller.html#a4d7533207ad88a89b8724adfc3fa6dbd", null ],
    [ "LoadStart", "class_main_menu_controller.html#aecb52914342c927d78c0046e46bb19b8", null ],
    [ "main_panel", "class_main_menu_controller.html#a92dc736765bf9e2c4b50b94b59f77d00", null ],
    [ "options_panel", "class_main_menu_controller.html#af3b65ac16536814c4cb6f657a56cfadc", null ],
    [ "to_visible_dur", "class_main_menu_controller.html#a92022b690dc92722e863cfa2830da61c", null ],
    [ "Instance", "class_main_menu_controller.html#a7b6358d43170c3d411ddaf576d05f07c", null ]
];