var class_resolution_options =
[
    [ "width", "class_resolution_options.html#af3d78dc99641baf244039b14e551b1cc", null ]
];