var class_text_data =
[
    [ "ShowText", "class_text_data.html#af258393180d336c9986148fcceac3545", null ],
    [ "eng_text", "class_text_data.html#a9173eb5afbfa8c792c8ead2869270379", null ],
    [ "spa_text", "class_text_data.html#adba784fadc520958a8319610a005982f", null ]
];