var class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button =
[
    [ "OnPointerDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html#a854d21df612c905d76e94202de62d7f4", null ],
    [ "OnPointerUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html#af74585809c7ae2aae9e0ee89fc21b689", null ],
    [ "axisName", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html#aa45ba9cf0514e4e7b6746b5d6cd8d6cc", null ],
    [ "axisValue", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html#ac90b2628193b482537c30818f236c8e8", null ],
    [ "responseSpeed", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html#adf1bf30668ea4383040d07ebb00fb373", null ],
    [ "returnToCentreSpeed", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html#a2a194c4af2b74c29b5388c9e0bffd4f5", null ]
];