var class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler =
[
    [ "SetAxisNegativeState", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a4385e667aabc4bd3c982b0ff8ae32933", null ],
    [ "SetAxisNeutralState", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a0c828c03ae8cc3f153d2b60063b6fbf8", null ],
    [ "SetAxisPositiveState", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a5fbaa8e9fdb70c05e7ba82bed1333e55", null ],
    [ "SetDownState", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a77cfb8fa2c78ff59e1a2cc20fd139943", null ],
    [ "SetUpState", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a88b2609ff142d16d32fd5c5e2b6db0c7", null ],
    [ "Update", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#ade485d05b86c16a062378cb34c169c2b", null ],
    [ "Name", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a7f295fca8edd514c0b8999ce0c78c34b", null ]
];