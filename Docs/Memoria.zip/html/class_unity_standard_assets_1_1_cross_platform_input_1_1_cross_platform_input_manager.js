var class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager =
[
    [ "VirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis" ],
    [ "VirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button" ],
    [ "ActiveInputMethod", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a4745a6f6fea88c350df29db10de7d4dd", [
      [ "Hardware", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a4745a6f6fea88c350df29db10de7d4dda3c02a379965ab0dfcd77b1c484450433", null ],
      [ "Touch", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a4745a6f6fea88c350df29db10de7d4ddaf0f31c9700c6b10d8a20dc487b2ae6a8", null ]
    ] ],
    [ "AxisExists", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a2b2ce7bfb83e8cc7f23b9f7fcf6dff5f", null ],
    [ "ButtonExists", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#abaceaf9f4dfd3ddecf0ab364c84c3d2d", null ],
    [ "GetAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#aac45b5560ebbc7c815dc22cba0dc1048", null ],
    [ "GetAxisRaw", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#ad5fefc184e12a2384ac780a7b79c034c", null ],
    [ "GetButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#abdeb5871a5d867418422070b3ff2483a", null ],
    [ "GetButtonDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a130706ec909ffbe649c9bc8534da8fa3", null ],
    [ "GetButtonUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#aef02595f4157113175d4c1be60402fbe", null ],
    [ "RegisterVirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a343c5d5b8bc64c0bace025f52e5e9c2d", null ],
    [ "RegisterVirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a2a1a682607122996df9e363a996bc4ad", null ],
    [ "SetAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#aaf138dbfc77d62b02679f3e156cc26b6", null ],
    [ "SetAxisNegative", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a2f7717dab92a1288e0cc6fdfbac750f1", null ],
    [ "SetAxisPositive", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a69563e20d7a30525e6873a03508ee127", null ],
    [ "SetAxisZero", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a8861163d3e2bba52c8d937caad7ae6be", null ],
    [ "SetButtonDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a2e30cf8aa09003f7501c1f0d59c1dd0b", null ],
    [ "SetButtonUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#adc185d28b9d06ee83035ef9b255682e1", null ],
    [ "SetVirtualMousePositionX", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a6170d9de0c506b1d6a6215df7d4accee", null ],
    [ "SetVirtualMousePositionY", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a48f3e5dbfe6617a6dedcf49e8788162f", null ],
    [ "SetVirtualMousePositionZ", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a94556375cf07502e86568bf9157a9f70", null ],
    [ "SwitchActiveInputMethod", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a095ca441f60cbd866d4221f4daea4a2e", null ],
    [ "UnRegisterVirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a1fe0c362a754984b83e2e228b0adf3a6", null ],
    [ "UnRegisterVirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#ae9e694bb5f52ff1311d8c0b3ab644276", null ],
    [ "VirtualAxisReference", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#ab494bb21f494748f2036d20a05d496df", null ],
    [ "mousePosition", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a38301395eaaa739f3f0794933a188280", null ]
];