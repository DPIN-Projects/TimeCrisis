var class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis =
[
    [ "VirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a051ce3991988d9ff11efe81e73491a68", null ],
    [ "VirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a4d1d1be133e80ab963a3ed6e3186971e", null ],
    [ "Remove", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#af4dc5cd83e45dc874b7b659f03cdc926", null ],
    [ "Update", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a53ab054e60e6e33fad9a62283786d962", null ],
    [ "GetValue", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a51bd6f837943d701ba4da4048873e88d", null ],
    [ "GetValueRaw", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a8a528d70054dedde487f12a2a8817bab", null ],
    [ "matchWithInputManager", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a0a36c8bbe98e6f8d28c92e3e259019c6", null ],
    [ "name", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a176a271ea7cb1d9b52194ac0894c1b7b", null ]
];