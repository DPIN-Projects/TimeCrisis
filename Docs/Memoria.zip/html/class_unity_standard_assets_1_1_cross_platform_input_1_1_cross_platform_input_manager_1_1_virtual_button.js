var class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button =
[
    [ "VirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a138a841bb53ba6eb68793aa15b677e09", null ],
    [ "VirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#aee8ba0ad3aaf52e8609f0e321e69c4c1", null ],
    [ "Pressed", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a286f1c4c3001579bf3268312620808e7", null ],
    [ "Released", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a0fc705bf079daeec58834c0eda4787ed", null ],
    [ "Remove", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#ac421e5de77f8384401a3e20d18101401", null ],
    [ "GetButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a00be3af37f8695641b92263b882f93fa", null ],
    [ "GetButtonDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#af331b4d07b4ba657cf2ef28ec9b6da7b", null ],
    [ "GetButtonUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#ac1c38eca63e5d5cc12113152bad02011", null ],
    [ "matchWithInputManager", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a463a12ebf8d58cbc22fd79fb0d5df773", null ],
    [ "name", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a2c32a0ba1321140c06327f467ed12071", null ]
];