var class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick =
[
    [ "AxisOption", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901", [
      [ "Both", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901a130c5b3473c57faa76e2a1c54e26f88e", null ],
      [ "OnlyHorizontal", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901aad0df54cc6571aea4edb7176c3149ef9", null ],
      [ "OnlyVertical", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901ae9490dd647be2142274984691da814fb", null ]
    ] ],
    [ "OnDrag", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a156c19bc0a3fe7a4c3b954e8c2c4a90e", null ],
    [ "OnPointerDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a8df75692befe2a2426f6eee7a7e5765c", null ],
    [ "OnPointerUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#ab7f7dbe18f7b229df10dd925534b4fbf", null ],
    [ "axesToUse", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#aa0a6ed91c54506a11323b7a9ac75af46", null ],
    [ "horizontalAxisName", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a1a2343df2c18d9afa642d6131bc0e5ad", null ],
    [ "MovementRange", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a7309ba63c7e16cfb230130b0ba1f8bd4", null ],
    [ "verticalAxisName", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#ab131c9265b8fa58aa7b22e3442c4aff7", null ]
];