var class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input =
[
    [ "GetAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a810b166597117356c6be8a77c5f60b87", null ],
    [ "GetButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#abae28eb1ca17a873cc6eed480085e0fb", null ],
    [ "GetButtonDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a6017fdff87802b504aafd55969807ae7", null ],
    [ "GetButtonUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#af86223b3eb0b0d81c794dbbee4f1c8fa", null ],
    [ "MousePosition", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a18dc43a362728639b76870ef6e141576", null ],
    [ "SetAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a1597873a4a9309a388a3e9239e2632d7", null ],
    [ "SetAxisNegative", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#ab657b9df7411909f1319c7ecf918689c", null ],
    [ "SetAxisPositive", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a045d6d8118178037cca1552c087f4598", null ],
    [ "SetAxisZero", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a94bfadda9797a34c9d66b30dd6449c2c", null ],
    [ "SetButtonDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#a56ecd8af7bf3e3d66fd1a171ad59343b", null ],
    [ "SetButtonUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html#acc7c93e48c46057a72b426b2bc9b9f4e", null ]
];