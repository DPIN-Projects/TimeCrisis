var class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input =
[
    [ "AxisMapping", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping" ],
    [ "AxisOptions", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#a33494fd997ae63aea22ffb585244f187", [
      [ "ForwardAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#a33494fd997ae63aea22ffb585244f187ab8587f332713f2facfcf4519ace9485b", null ],
      [ "SidewaysAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#a33494fd997ae63aea22ffb585244f187a96496b3cd12539f92ebfcab10dbc0e64", null ]
    ] ],
    [ "centreAngleOffset", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#aac904601039bbf6561ee00f0d492c941", null ],
    [ "fullTiltAngle", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#a92a6ef18b52f2409658b7a50037ac831", null ],
    [ "mapping", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#a825e259327ff4204d651876bb30d22f9", null ],
    [ "tiltAroundAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html#ad83fbef4affa001aab207586dd91e2e7", null ]
];