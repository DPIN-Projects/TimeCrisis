var class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping =
[
    [ "MappingType", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a237892bdafa6578dcf66b355a470e58b", [
      [ "NamedAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a237892bdafa6578dcf66b355a470e58bab73b0008438fcc7880d4265328382684", null ],
      [ "MousePositionX", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a237892bdafa6578dcf66b355a470e58ba2e5d285ad44c4b5c60c19d821f837597", null ],
      [ "MousePositionY", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a237892bdafa6578dcf66b355a470e58ba34a9ef3987b77e6cb421e0f99aa29500", null ],
      [ "MousePositionZ", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a237892bdafa6578dcf66b355a470e58ba29cefbe721516636bf49ac7a3dd92516", null ]
    ] ],
    [ "axisName", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a75b32887fe2065f3c67cdda50b2b9c00", null ],
    [ "type", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#aba5d982b878f8b4e15867b731782ed63", null ]
];