var class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad =
[
    [ "AxisOption", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5", [
      [ "Both", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5a130c5b3473c57faa76e2a1c54e26f88e", null ],
      [ "OnlyHorizontal", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5aad0df54cc6571aea4edb7176c3149ef9", null ],
      [ "OnlyVertical", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5ae9490dd647be2142274984691da814fb", null ]
    ] ],
    [ "ControlStyle", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#ab4c68ac6f2b8a41c5029c105833ebfb6", [
      [ "Absolute", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#ab4c68ac6f2b8a41c5029c105833ebfb6ab51ca26c6c89cfc9bec338f7a0d3e0c8", null ],
      [ "Relative", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#ab4c68ac6f2b8a41c5029c105833ebfb6a2ca9469819fb0fb61ff98e914a7ccca0", null ],
      [ "Swipe", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#ab4c68ac6f2b8a41c5029c105833ebfb6a78076ce792c4640bf99c598c92bd69e7", null ]
    ] ],
    [ "OnPointerDown", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a8b4472a5a1e14f366343555bde2a0d5f", null ],
    [ "OnPointerUp", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a4dba9a8b6dfe34618e48f1b152bc1eba", null ],
    [ "axesToUse", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a0ad06c7691faa5b86e3917bdab8d3eae", null ],
    [ "controlStyle", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#ad6ec0252344c6ee56d386f560e0b2240", null ],
    [ "horizontalAxisName", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a585071611ca85f0bd127c0fd8e25f0eb", null ],
    [ "verticalAxisName", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a1338b6e2123c8547d13f4adad495f9e0", null ],
    [ "Xsensitivity", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a32afeb376c688e6faeec4de083d1e256", null ],
    [ "Ysensitivity", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a2481cb2206a2127c4abe6945621752ab", null ]
];