var class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_definition =
[
    [ "original", "class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_definition.html#aedda6be7e719ff5127ba07a7c194359f", null ],
    [ "replacement", "class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_definition.html#aa969ba1a979e7f9b4364fa9d9c4de934", null ]
];