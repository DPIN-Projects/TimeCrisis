var class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_list =
[
    [ "items", "class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_list.html#a66f83004343262d054bd122a2ea6cb9f", null ]
];