var class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate =
[
    [ "Vector3andSpace", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate_1_1_vector3and_space.html", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate_1_1_vector3and_space" ],
    [ "ignoreTimescale", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate.html#a976e08503afdbe2ecc8167b224bc63de", null ],
    [ "moveUnitsPerSecond", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate.html#ac1c663ec1f1d0f5f3659506a9738bd32", null ],
    [ "rotateDegreesPerSecond", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate.html#a44e784fd8e9253c3ae420024be95b0e2", null ]
];