var class_unity_standard_assets_1_1_utility_1_1_camera_refocus =
[
    [ "CameraRefocus", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#ad18f0defd5d32b13fdfee175e4a5d9ba", null ],
    [ "ChangeCamera", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#a4b06686fe002ec8b589dd5e91b9251e5", null ],
    [ "ChangeParent", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#a3d41f2de5bf72909ace12fab7003a2bc", null ],
    [ "GetFocusPoint", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#ae40dc3974276cd4f3b39dbfff2c68996", null ],
    [ "SetFocusPoint", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#a96116de559e0039593ceda8a97574b6c", null ],
    [ "Camera", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#af2e66852407defac8d42928618ac667f", null ],
    [ "Lookatpoint", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#a1befa53fb7728dcc2fa0e4862dd60543", null ],
    [ "Parent", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html#ab5d9f1645e7f5f07c617be54fe20bd14", null ]
];