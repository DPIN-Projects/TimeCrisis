var class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings =
[
    [ "adaptTime", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#acfdb112f4fd773a817eb266d6bfa8090", null ],
    [ "maxHeight", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#a7bd34b65a3aee3e55bfc86fdcb83d6f1", null ],
    [ "maxShadowBias", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#a3fb2ab54f5e9d224306a8589d00ee395", null ],
    [ "maxShadowDistance", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#a3a8c3949474554f330ad054b40fad3e2", null ],
    [ "minHeight", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#afadfe15321200124d550b56ffd1a113b", null ],
    [ "minShadowBias", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#acf6fe9ea39b4dd184d9f2d60ea4bc1d3", null ],
    [ "minShadowDistance", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#aee0894c90bbed7f83d5ced9b3f4b72d7", null ],
    [ "sunLight", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html#a9113da6dce94c015bfefb8542e40b35a", null ]
];