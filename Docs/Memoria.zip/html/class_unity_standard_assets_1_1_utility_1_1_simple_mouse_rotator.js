var class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator =
[
    [ "autoZeroHorizontalOnMobile", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html#a2c478b280f5cc6aabd0748ff942aa70a", null ],
    [ "autoZeroVerticalOnMobile", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html#aa760458c2ee655aaa3d0070d232e0bd8", null ],
    [ "dampingTime", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html#a85aa6523ef427b26aa06e2bf72065c2a", null ],
    [ "relative", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html#ae3fa7d106b4665c21827c83c0f536b6d", null ],
    [ "rotationRange", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html#af79ed9357370019db5ce36b6915d570f", null ],
    [ "rotationSpeed", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html#afc9602d14db21096a9777a6eaba4fbb5", null ]
];