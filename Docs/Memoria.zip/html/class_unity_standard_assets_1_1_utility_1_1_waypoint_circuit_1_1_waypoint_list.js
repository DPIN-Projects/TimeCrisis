var class_unity_standard_assets_1_1_utility_1_1_waypoint_circuit_1_1_waypoint_list =
[
    [ "circuit", "class_unity_standard_assets_1_1_utility_1_1_waypoint_circuit_1_1_waypoint_list.html#a8a024d382de1b36d054562f150533035", null ],
    [ "items", "class_unity_standard_assets_1_1_utility_1_1_waypoint_circuit_1_1_waypoint_list.html#af44d62dad0eb5964ba20ec2b9a39372f", null ]
];