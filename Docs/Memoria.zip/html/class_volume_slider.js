var class_volume_slider =
[
    [ "VolumeType", "class_volume_slider.html#ab8740b268763fe217a5aadaf3015a56d", [
      [ "Music", "class_volume_slider.html#ab8740b268763fe217a5aadaf3015a56da47dcbd834e669233d7eb8a51456ed217", null ],
      [ "SFX", "class_volume_slider.html#ab8740b268763fe217a5aadaf3015a56dada101052f6ba998ab41d571a6fff1708", null ]
    ] ],
    [ "OnPointerUp", "class_volume_slider.html#ad38e73994ae77db0e9726f6e5098021c", null ],
    [ "vol_type", "class_volume_slider.html#a8392c584c3efd3e53a5d13c92c0d7408", null ]
];