var dir_38c0671d8e669cdaf9fe4d0c8e0456be =
[
    [ "DoxygenWindow.cs", "_doxygen_window_8cs.html", [
      [ "DoxygenConfig", "class_doxygen_config.html", "class_doxygen_config" ],
      [ "DoxygenWindow", "class_doxygen_window.html", "class_doxygen_window" ],
      [ "DoxyRunner", "class_doxy_runner.html", "class_doxy_runner" ],
      [ "DoxyThreadSafeOutput", "class_doxy_thread_safe_output.html", "class_doxy_thread_safe_output" ]
    ] ]
];