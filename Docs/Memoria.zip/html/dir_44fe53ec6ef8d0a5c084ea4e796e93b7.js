var dir_44fe53ec6ef8d0a5c084ea4e796e93b7 =
[
    [ "PlatformSpecific", "dir_5f5d945be8e011928679f217c22982eb.html", "dir_5f5d945be8e011928679f217c22982eb" ],
    [ "AxisTouchButton.cs", "_axis_touch_button_8cs.html", [
      [ "AxisTouchButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button" ]
    ] ],
    [ "ButtonHandler.cs", "_button_handler_8cs.html", [
      [ "ButtonHandler", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler" ]
    ] ],
    [ "CrossPlatformInputManager.cs", "_cross_platform_input_manager_8cs.html", [
      [ "CrossPlatformInputManager", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager" ],
      [ "VirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis" ],
      [ "VirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button" ]
    ] ],
    [ "InputAxisScrollbar.cs", "_input_axis_scrollbar_8cs.html", [
      [ "InputAxisScrollbar", "class_unity_standard_assets_1_1_cross_platform_input_1_1_input_axis_scrollbar.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_input_axis_scrollbar" ]
    ] ],
    [ "Joystick.cs", "_joystick_8cs.html", [
      [ "Joystick", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick" ]
    ] ],
    [ "MobileControlRig.cs", "_mobile_control_rig_8cs.html", [
      [ "MobileControlRig", "class_unity_standard_assets_1_1_cross_platform_input_1_1_mobile_control_rig.html", null ]
    ] ],
    [ "TiltInput.cs", "_tilt_input_8cs.html", [
      [ "TiltInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input" ],
      [ "AxisMapping", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping" ]
    ] ],
    [ "TouchPad.cs", "_touch_pad_8cs.html", [
      [ "TouchPad", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad" ]
    ] ],
    [ "VirtualInput.cs", "_virtual_input_8cs.html", [
      [ "VirtualInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_virtual_input.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_virtual_input" ]
    ] ]
];