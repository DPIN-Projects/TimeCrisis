var dir_54917bde386a5ef9e0c3f63ca6b256ef =
[
    [ "AudioMan.cs", "_audio_man_8cs.html", [
      [ "AudioMan", "class_audio_man.html", "class_audio_man" ]
    ] ],
    [ "GameMan.cs", "_game_man_8cs.html", [
      [ "GameMan", "class_game_man.html", null ]
    ] ],
    [ "GraphicsMan.cs", "_graphics_man_8cs.html", [
      [ "GraphicsMan", "class_graphics_man.html", "class_graphics_man" ]
    ] ],
    [ "LanguageMan.cs", "_language_man_8cs.html", [
      [ "LanguageMan", "class_language_man.html", "class_language_man" ]
    ] ],
    [ "SceneMan.cs", "_scene_man_8cs.html", [
      [ "SceneMan", "class_scene_man.html", "class_scene_man" ]
    ] ]
];