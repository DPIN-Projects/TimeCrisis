var dir_885eae48efb7daa5576f0054646f3a6a =
[
    [ "FullscreenToggle.cs", "_fullscreen_toggle_8cs.html", [
      [ "FullscreenToggle", "class_fullscreen_toggle.html", null ]
    ] ],
    [ "LanguageOptions.cs", "_language_options_8cs.html", [
      [ "LanguageOptions", "class_language_options.html", "class_language_options" ]
    ] ],
    [ "MainMenuController.cs", "_main_menu_controller_8cs.html", [
      [ "MainMenuController", "class_main_menu_controller.html", "class_main_menu_controller" ]
    ] ],
    [ "ResolutionOptions.cs", "_resolution_options_8cs.html", [
      [ "ResolutionOptions", "class_resolution_options.html", "class_resolution_options" ]
    ] ],
    [ "VolumeSlider.cs", "_volume_slider_8cs.html", [
      [ "VolumeSlider", "class_volume_slider.html", "class_volume_slider" ]
    ] ]
];