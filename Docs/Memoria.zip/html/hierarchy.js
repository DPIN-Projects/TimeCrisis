var hierarchy =
[
    [ "UnityStandardAssets.Characters.FirstPerson.RigidbodyFirstPersonController.AdvancedSettings", "class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_rigidbody_first_person_controller_1_1_advanced_settings.html", null ],
    [ "UnityStandardAssets.CrossPlatformInput.TiltInput.AxisMapping", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html", null ],
    [ "UnityStandardAssets.Utility.CameraRefocus", "class_unity_standard_assets_1_1_utility_1_1_camera_refocus.html", null ],
    [ "UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html", null ],
    [ "UnityStandardAssets.Utility.CurveControlledBob", "class_unity_standard_assets_1_1_utility_1_1_curve_controlled_bob.html", null ],
    [ "DoxygenConfig", "class_doxygen_config.html", null ],
    [ "DoxyRunner", "class_doxy_runner.html", null ],
    [ "DoxyThreadSafeOutput", "class_doxy_thread_safe_output.html", null ],
    [ "EditorWindow", null, [
      [ "DoxygenWindow", "class_doxygen_window.html", null ]
    ] ],
    [ "UnityStandardAssets.Utility.TimedObjectActivator.Entries", "class_unity_standard_assets_1_1_utility_1_1_timed_object_activator_1_1_entries.html", null ],
    [ "UnityStandardAssets.Utility.TimedObjectActivator.Entry", "class_unity_standard_assets_1_1_utility_1_1_timed_object_activator_1_1_entry.html", null ],
    [ "UnityStandardAssets.Utility.FOVKick", "class_unity_standard_assets_1_1_utility_1_1_f_o_v_kick.html", null ],
    [ "ICanvasRaycastFilter", null, [
      [ "AlphaButtonClickMask", "class_alpha_button_click_mask.html", null ]
    ] ],
    [ "IDragHandler", null, [
      [ "UnityStandardAssets.CrossPlatformInput.Joystick", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html", null ]
    ] ],
    [ "IPointerDownHandler", null, [
      [ "UnityStandardAssets.CrossPlatformInput.AxisTouchButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.Joystick", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.TouchPad", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html", null ]
    ] ],
    [ "IPointerUpHandler", null, [
      [ "UnityStandardAssets.CrossPlatformInput.AxisTouchButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.Joystick", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.TouchPad", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html", null ],
      [ "VolumeSlider", "class_volume_slider.html", null ]
    ] ],
    [ "UnityStandardAssets.Utility.LerpControlledBob", "class_unity_standard_assets_1_1_utility_1_1_lerp_controlled_bob.html", null ],
    [ "MonoBehaviour", null, [
      [ "AlphaButtonClickMask", "class_alpha_button_click_mask.html", null ],
      [ "AudioMan", "class_audio_man.html", null ],
      [ "AutoLevel", "class_auto_level.html", null ],
      [ "CursorController", "class_cursor_controller.html", null ],
      [ "DDOL", "class_d_d_o_l.html", null ],
      [ "DevPreLoad", "class_dev_pre_load.html", null ],
      [ "EventSystemChecker", "class_event_system_checker.html", null ],
      [ "ForcedReset", "class_forced_reset.html", null ],
      [ "FullscreenToggle", "class_fullscreen_toggle.html", null ],
      [ "GameMan", "class_game_man.html", null ],
      [ "GraphicsMan", "class_graphics_man.html", null ],
      [ "GunController", "class_gun_controller.html", null ],
      [ "LanguageMan", "class_language_man.html", null ],
      [ "LanguageOptions", "class_language_options.html", null ],
      [ "Loading", "class_loading.html", null ],
      [ "MainMenuController", "class_main_menu_controller.html", null ],
      [ "MusicController", "class_music_controller.html", null ],
      [ "PlayerController", "class_player_controller.html", null ],
      [ "ResolutionOptions", "class_resolution_options.html", null ],
      [ "SceneMan", "class_scene_man.html", null ],
      [ "TextData", "class_text_data.html", null ],
      [ "UnityStandardAssets.Characters.FirstPerson.FirstPersonController", "class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_first_person_controller.html", null ],
      [ "UnityStandardAssets.Characters.FirstPerson.HeadBob", "class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_head_bob.html", null ],
      [ "UnityStandardAssets.Characters.FirstPerson.RigidbodyFirstPersonController", "class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_rigidbody_first_person_controller.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.AxisTouchButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.ButtonHandler", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.InputAxisScrollbar", "class_unity_standard_assets_1_1_cross_platform_input_1_1_input_axis_scrollbar.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.Joystick", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.MobileControlRig", "class_unity_standard_assets_1_1_cross_platform_input_1_1_mobile_control_rig.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.TiltInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.TouchPad", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html", null ],
      [ "UnityStandardAssets.Utility.ActivateTrigger", "class_unity_standard_assets_1_1_utility_1_1_activate_trigger.html", null ],
      [ "UnityStandardAssets.Utility.AutoMobileShaderSwitch", "class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch.html", null ],
      [ "UnityStandardAssets.Utility.AutoMoveAndRotate", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate.html", null ],
      [ "UnityStandardAssets.Utility.DragRigidbody", "class_unity_standard_assets_1_1_utility_1_1_drag_rigidbody.html", null ],
      [ "UnityStandardAssets.Utility.DynamicShadowSettings", "class_unity_standard_assets_1_1_utility_1_1_dynamic_shadow_settings.html", null ],
      [ "UnityStandardAssets.Utility.FollowTarget", "class_unity_standard_assets_1_1_utility_1_1_follow_target.html", null ],
      [ "UnityStandardAssets.Utility.FPSCounter", "class_unity_standard_assets_1_1_utility_1_1_f_p_s_counter.html", null ],
      [ "UnityStandardAssets.Utility.ObjectResetter", "class_unity_standard_assets_1_1_utility_1_1_object_resetter.html", null ],
      [ "UnityStandardAssets.Utility.ParticleSystemDestroyer", "class_unity_standard_assets_1_1_utility_1_1_particle_system_destroyer.html", null ],
      [ "UnityStandardAssets.Utility.PlatformSpecificContent", "class_unity_standard_assets_1_1_utility_1_1_platform_specific_content.html", null ],
      [ "UnityStandardAssets.Utility.SimpleActivatorMenu", "class_unity_standard_assets_1_1_utility_1_1_simple_activator_menu.html", null ],
      [ "UnityStandardAssets.Utility.SimpleMouseRotator", "class_unity_standard_assets_1_1_utility_1_1_simple_mouse_rotator.html", null ],
      [ "UnityStandardAssets.Utility.SmoothFollow", "class_unity_standard_assets_1_1_utility_1_1_smooth_follow.html", null ],
      [ "UnityStandardAssets.Utility.TimedObjectActivator", "class_unity_standard_assets_1_1_utility_1_1_timed_object_activator.html", null ],
      [ "UnityStandardAssets.Utility.TimedObjectDestructor", "class_unity_standard_assets_1_1_utility_1_1_timed_object_destructor.html", null ],
      [ "UnityStandardAssets.Utility.WaypointCircuit", "class_unity_standard_assets_1_1_utility_1_1_waypoint_circuit.html", null ],
      [ "UnityStandardAssets.Utility.WaypointProgressTracker", "class_unity_standard_assets_1_1_utility_1_1_waypoint_progress_tracker.html", null ],
      [ "VolumeSlider", "class_volume_slider.html", null ]
    ] ],
    [ "UnityStandardAssets.Characters.FirstPerson.MouseLook", "class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_mouse_look.html", null ],
    [ "UnityStandardAssets.Characters.FirstPerson.RigidbodyFirstPersonController.MovementSettings", "class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_rigidbody_first_person_controller_1_1_movement_settings.html", null ],
    [ "UnityStandardAssets.Utility.AutoMobileShaderSwitch.ReplacementDefinition", "class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_definition.html", null ],
    [ "UnityStandardAssets.Utility.AutoMobileShaderSwitch.ReplacementList", "class_unity_standard_assets_1_1_utility_1_1_auto_mobile_shader_switch_1_1_replacement_list.html", null ],
    [ "UnityStandardAssets.Utility.WaypointCircuit.RoutePoint", "struct_unity_standard_assets_1_1_utility_1_1_waypoint_circuit_1_1_route_point.html", null ],
    [ "ScriptableObject", null, [
      [ "GunData", "class_gun_data.html", null ]
    ] ],
    [ "UnityStandardAssets.Utility.AutoMoveAndRotate.Vector3andSpace", "class_unity_standard_assets_1_1_utility_1_1_auto_move_and_rotate_1_1_vector3and_space.html", null ],
    [ "UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.VirtualAxis", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html", null ],
    [ "UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.VirtualButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html", null ],
    [ "UnityStandardAssets.CrossPlatformInput.VirtualInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_virtual_input.html", [
      [ "UnityStandardAssets.CrossPlatformInput.PlatformSpecific.MobileInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_mobile_input.html", null ],
      [ "UnityStandardAssets.CrossPlatformInput.PlatformSpecific.StandaloneInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific_1_1_standalone_input.html", null ]
    ] ],
    [ "UnityStandardAssets.Utility.WaypointCircuit.WaypointList", "class_unity_standard_assets_1_1_utility_1_1_waypoint_circuit_1_1_waypoint_list.html", null ]
];