var namespace_unity_standard_assets =
[
    [ "Characters", "namespace_unity_standard_assets_1_1_characters.html", "namespace_unity_standard_assets_1_1_characters" ],
    [ "CrossPlatformInput", "namespace_unity_standard_assets_1_1_cross_platform_input.html", "namespace_unity_standard_assets_1_1_cross_platform_input" ],
    [ "UnityStandardAssets", "namespace_unity_standard_assets_1_1_unity_standard_assets.html", "namespace_unity_standard_assets_1_1_unity_standard_assets" ],
    [ "Utility", "namespace_unity_standard_assets_1_1_utility.html", "namespace_unity_standard_assets_1_1_utility" ]
];