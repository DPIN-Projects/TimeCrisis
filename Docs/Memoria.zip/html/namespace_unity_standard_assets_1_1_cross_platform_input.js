var namespace_unity_standard_assets_1_1_cross_platform_input =
[
    [ "PlatformSpecific", "namespace_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific.html", "namespace_unity_standard_assets_1_1_cross_platform_input_1_1_platform_specific" ],
    [ "AxisTouchButton", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_axis_touch_button" ],
    [ "ButtonHandler", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler" ],
    [ "CrossPlatformInputManager", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager" ],
    [ "InputAxisScrollbar", "class_unity_standard_assets_1_1_cross_platform_input_1_1_input_axis_scrollbar.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_input_axis_scrollbar" ],
    [ "Joystick", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick" ],
    [ "MobileControlRig", "class_unity_standard_assets_1_1_cross_platform_input_1_1_mobile_control_rig.html", null ],
    [ "TiltInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input" ],
    [ "TouchPad", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad" ],
    [ "VirtualInput", "class_unity_standard_assets_1_1_cross_platform_input_1_1_virtual_input.html", "class_unity_standard_assets_1_1_cross_platform_input_1_1_virtual_input" ]
];