var namespace_unity_standard_assets_1_1_unity_standard_assets =
[
    [ "CrossPlatformInput", "namespace_unity_standard_assets_1_1_unity_standard_assets_1_1_cross_platform_input.html", null ],
    [ "Utility", "namespace_unity_standard_assets_1_1_unity_standard_assets_1_1_utility.html", null ]
];