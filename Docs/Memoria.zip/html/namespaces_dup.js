var namespaces_dup =
[
    [ "UnityStandardAssets", "namespace_unity_standard_assets.html", "namespace_unity_standard_assets" ]
];