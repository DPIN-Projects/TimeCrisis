var searchData=
[
  ['xsensitivity',['XSensitivity',['../class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_mouse_look.html#a162641b3a40e7728efd2686c0262cea1',1,'UnityStandardAssets.Characters.FirstPerson.MouseLook.XSensitivity()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a32afeb376c688e6faeec4de083d1e256',1,'UnityStandardAssets.CrossPlatformInput.TouchPad.Xsensitivity()']]]
];
