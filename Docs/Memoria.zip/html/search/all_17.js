var searchData=
[
  ['ysensitivity',['YSensitivity',['../class_unity_standard_assets_1_1_characters_1_1_first_person_1_1_mouse_look.html#a2e8ac09236a95f05a007d700e6b738e2',1,'UnityStandardAssets.Characters.FirstPerson.MouseLook.YSensitivity()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a2481cb2206a2127c4abe6945621752ab',1,'UnityStandardAssets.CrossPlatformInput.TouchPad.Ysensitivity()']]]
];
