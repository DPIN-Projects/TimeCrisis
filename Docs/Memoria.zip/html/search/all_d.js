var searchData=
[
  ['name',['Name',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_button_handler.html#a7f295fca8edd514c0b8999ce0c78c34b',1,'UnityStandardAssets.CrossPlatformInput.ButtonHandler.Name()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_axis.html#a176a271ea7cb1d9b52194ac0894c1b7b',1,'UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.VirtualAxis.name()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager_1_1_virtual_button.html#a2c32a0ba1321140c06327f467ed12071',1,'UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.VirtualButton.name()']]],
  ['namedaxis',['NamedAxis',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_tilt_input_1_1_axis_mapping.html#a237892bdafa6578dcf66b355a470e58bab73b0008438fcc7880d4265328382684',1,'UnityStandardAssets::CrossPlatformInput::TiltInput::AxisMapping']]],
  ['nextcamera',['NextCamera',['../class_unity_standard_assets_1_1_utility_1_1_simple_activator_menu.html#a335468ed4d932d4aeb83a676c0a98b0e',1,'UnityStandardAssets::Utility::SimpleActivatorMenu']]],
  ['nextlanguage',['NextLanguage',['../class_language_options.html#a0b9b2fa39befb1df062361cac0859f66',1,'LanguageOptions']]],
  ['numberoftypes',['NumberOfTypes',['../class_language_man.html#a17847f05d76a6c54d90b32629d4d91d3ac547342537ca85aeb8be82a349cbb6a2',1,'LanguageMan']]]
];
