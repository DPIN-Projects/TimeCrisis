var searchData=
[
  ['both',['Both',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901a130c5b3473c57faa76e2a1c54e26f88e',1,'UnityStandardAssets.CrossPlatformInput.Joystick.Both()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5a130c5b3473c57faa76e2a1c54e26f88e',1,'UnityStandardAssets.CrossPlatformInput.TouchPad.Both()']]]
];
