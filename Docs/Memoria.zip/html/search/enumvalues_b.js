var searchData=
[
  ['onlyhorizontal',['OnlyHorizontal',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901aad0df54cc6571aea4edb7176c3149ef9',1,'UnityStandardAssets.CrossPlatformInput.Joystick.OnlyHorizontal()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5aad0df54cc6571aea4edb7176c3149ef9',1,'UnityStandardAssets.CrossPlatformInput.TouchPad.OnlyHorizontal()']]],
  ['onlyvertical',['OnlyVertical',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_joystick.html#a6d8c31bfbf3b5fb568caa04cfd87f901ae9490dd647be2142274984691da814fb',1,'UnityStandardAssets.CrossPlatformInput.Joystick.OnlyVertical()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_touch_pad.html#a97d0cfd4e00c26253919746e84ebb7e5ae9490dd647be2142274984691da814fb',1,'UnityStandardAssets.CrossPlatformInput.TouchPad.OnlyVertical()']]]
];
