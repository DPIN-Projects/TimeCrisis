var searchData=
[
  ['touch',['Touch',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#a4745a6f6fea88c350df29db10de7d4ddaf0f31c9700c6b10d8a20dc487b2ae6a8',1,'UnityStandardAssets::CrossPlatformInput::CrossPlatformInputManager']]],
  ['trigger',['Trigger',['../class_unity_standard_assets_1_1_utility_1_1_activate_trigger.html#a4e33cb00af0eb967c03fbe756f487b00af698f67f5666aff10729d8a1cb1c14d2',1,'UnityStandardAssets::Utility::ActivateTrigger']]]
];
