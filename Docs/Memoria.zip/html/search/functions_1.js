var searchData=
[
  ['buttonexists',['ButtonExists',['../class_unity_standard_assets_1_1_cross_platform_input_1_1_cross_platform_input_manager.html#abaceaf9f4dfd3ddecf0ab364c84c3d2d',1,'UnityStandardAssets.CrossPlatformInput.CrossPlatformInputManager.ButtonExists()'],['../class_unity_standard_assets_1_1_cross_platform_input_1_1_virtual_input.html#a5d70deed210f91fc144d9a62cab4c535',1,'UnityStandardAssets.CrossPlatformInput.VirtualInput.ButtonExists()']]]
];
